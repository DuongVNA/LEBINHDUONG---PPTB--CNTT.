# Hybrid Airlines — Full Observability Stack
**One command** to bring up: App (Blue/Green + Canary sticky) + NGINX gateway + OpenTelemetry Collector + **Prometheus + Grafana (auto-provisioned)** + **Jaeger**.

## Quick start
```bash
docker compose up -d --build
# Gateway:     http://127.0.0.1:8080
# Grafana:     http://127.0.0.1:3000  (admin / admin)  -> Dashboard auto-imported
# Prometheus:  http://127.0.0.1:9090
# Jaeger UI:   http://127.0.0.1:16686

# Switch traffic
./scripts/switch_mode.sh canary 20
curl -s http://127.0.0.1:8080/whoami
```
