#!/usr/bin/env bash
set -euo pipefail
MODE="${1:-blue}"
PCT="${2:-10}"
CONF_DIR=./gateway/conf.d
MODE_TXT=./gateway/html/mode.txt

case "$MODE" in
  blue) cp -f "$CONF_DIR/mode.blue.conf" "$CONF_DIR/mode.conf"; echo "blue" > "$MODE_TXT" ;;
  green) cp -f "$CONF_DIR/mode.green.conf" "$CONF_DIR/mode.conf"; echo "green" > "$MODE_TXT" ;;
  canary)
    PBLUE=$((100 - PCT))
    cat > "$CONF_DIR/mode.conf" <<EOF
map $canary_prefer $active_pool { 1 app_green; 0 app_split; }
upstream app_split {
  hash $remote_addr consistent;
  server app_blue  weight=${PBLUE};
  server app_green weight=${PCT};
}
EOF
    echo "canary:${PCT}%" > "$MODE_TXT"
    ;;
  *) echo "Usage: $0 {blue|green|canary <pct>}"; exit 1;;
esac

# reload gateway if running
if docker ps --format '{{.Names}}' | grep -q gateway; then
  docker exec $(docker ps --format '{{.Names}}' | grep gateway) nginx -s reload || true
fi
echo "Mode -> $(cat $MODE_TXT)"
