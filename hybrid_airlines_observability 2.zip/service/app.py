from flask import Flask, jsonify, make_response, request
import os

app = Flask(__name__)
COLOR = os.getenv("APP_COLOR","blue")

@app.get("/")
def root():
    return f"<h1>Airlines App — {COLOR.upper()}</h1>\n"

@app.get("/healthz")
def health():
    return make_response(("ok\n",200,{"Content-Type":"text/plain"}))

@app.get("/whoami")
def who():
    return jsonify(color=COLOR, ip=request.remote_addr)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
