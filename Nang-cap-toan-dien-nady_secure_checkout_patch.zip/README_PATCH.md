# Nady Secure Checkout Patch (Runnable)

This patch adds: Anti‑bot (Turnstile + Redis sliding window), secure webhooks (MoMo + PayPal), idempotency, and optional Stripe 3DS2.

## 1) Install dependencies
```bash
npm i redis stripe zod
```

## 2) Environment (.env example)
```
REDIS_URL=redis://default:<password>@<host>:6379
TURNSTILE_SECRET_KEY=1x0000000000000000000000000000000AA
NEXT_PUBLIC_BASE_URL=https://your-domain.com

MOMO_SECRET_KEY=xxxx
MOMO_PARTNER_CODE=MOMOXxx
MOMO_ENDPOINT=https://test-payment.momo.vn/v2/gateway/api/create

PAYPAL_CLIENT_ID=...
PAYPAL_CLIENT_SECRET=...
PAYPAL_WEBHOOK_ID=...
PAYPAL_API=https://api-m.sandbox.paypal.com

STRIPE_SECRET_KEY=sk_test_...
```

## 3) File layout (copy into your Next.js project)
Put `app` routes under your `src/app` (or `app`) folder; adjust import path to your prisma client at `@/lib/db`.

- `middleware.ts`
- `src/lib/security.ts`
- `src/utils/rate.ts`
- `src/app/api/turnstile-verify/route.ts`
- `src/app/api/checkout/route.ts`
- `src/app/api/webhook/momo/route.ts`
- `src/app/api/webhook/paypal/route.ts`
- `prisma/schema.snippet.prisma` (append to your schema + migrate)

## 4) Prisma migrate
Append `schema.snippet.prisma` to your `prisma/schema.prisma` and run:
```bash
npx prisma migrate dev -n add_payment_events
```

## 5) Run
```bash
npm run dev
# or deploy behind HTTPS + Cloudflare
```

> Tip: Protect `/api/webhook/*` by WAF allow-list for provider IPs in production.
