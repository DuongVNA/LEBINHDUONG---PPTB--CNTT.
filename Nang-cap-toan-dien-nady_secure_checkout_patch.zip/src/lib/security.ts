import crypto from 'crypto'

export function hmacSHA256(raw: string, secret: string) {
  return crypto.createHmac('sha256', secret).update(raw, 'utf8').digest('hex')
}

export function constantTimeEqual(a: string, b: string) {
  const ab = Buffer.from(a, 'utf8')
  const bb = Buffer.from(b, 'utf8')
  if (ab.length !== bb.length) return false
  return crypto.timingSafeEqual(ab, bb)
}

export function canonicalize(obj: Record<string, any>) {
  return Object.keys(obj)
    .sort()
    .map(k => `${k}=${String(obj[k])}`)
    .join('&')
}
