import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  const { token, remoteip } = await req.json()
  const form = new URLSearchParams()
  form.append('secret', process.env.TURNSTILE_SECRET_KEY!)
  form.append('response', token)
  if (remoteip) form.append('remoteip', remoteip)

  const r = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', { method: 'POST', body: form })
  const json = await r.json()
  return NextResponse.json(json, { status: json.success ? 200 : 400 })
}
