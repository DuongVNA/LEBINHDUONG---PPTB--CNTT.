import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { hmacSHA256 } from '@/lib/security'
import { z } from 'zod'

const Checkout = z.object({
  amount: z.number().positive(),
  method: z.enum(['momo','stripe']),
  orderId: z.string().min(6).max(64),
  turnstileToken: z.string().min(10)
})

export async function POST(req: Request) {
  const body = Checkout.parse(await req.json())
  const { amount, method, orderId, turnstileToken } = body

  const ver = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/api/turnstile-verify`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token: turnstileToken })
  }).then(r => r.json()).catch(() => ({ success: false }))
  if (!ver.success) return NextResponse.json({ error: 'bot_detected' }, { status: 400 })

  const idemKey = `checkout:${method}:${orderId}`
  const existed = await prisma.idempotencyKey.findUnique({ where: { key: idemKey } })
  if (existed) return NextResponse.json({ ok: true, reused: true }, { status: 200 })

  await prisma.$transaction(async (tx) => {
    await tx.order.upsert({
      where: { id: orderId },
      update: { amount, status: 'PENDING' },
      create: { id: orderId, amount, status: 'PENDING' }
    })
    await tx.payment.create({ data: { orderId, amount, status: 'PENDING', provider: method } })
    await tx.idempotencyKey.create({ data: { key: idemKey, response: '' } })
  })

  if (method === 'momo') {
    const payload: any = {
      amount, orderId, requestType: 'captureWallet',
      partnerCode: process.env.MOMO_PARTNER_CODE,
      returnUrl: `${process.env.NEXT_PUBLIC_BASE_URL}/thank-you?orderId=${orderId}`,
      notifyUrl: `${process.env.NEXT_PUBLIC_BASE_URL}/api/webhook/momo`
    }
    const raw = Object.keys(payload).sort().map(k => `${k}=${payload[k]}`).join('&')
    const signature = hmacSHA256(raw, process.env.MOMO_SECRET_KEY!)

    const res = await fetch(process.env.MOMO_ENDPOINT!, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...payload, signature })
    })
    const json = await res.json()
    if (!res.ok) return NextResponse.json({ error: 'momo_error', json }, { status: 400 })
    return NextResponse.json({ redirect: json.payUrl, provider: 'momo' })
  }

  if (method === 'stripe') {
    const stripe = new (await import('stripe')).default(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2025-01-27' })
    const pi = await stripe.paymentIntents.create({
      amount: Math.round(Number(amount) * 100),
      currency: 'vnd',
      automatic_payment_methods: { enabled: true },
      payment_method_options: { card: { request_three_d_secure: 'automatic' } },
      metadata: { orderId }
    })
    return NextResponse.json({ clientSecret: pi.client_secret, provider: 'stripe' })
  }

  return NextResponse.json({ error: 'unsupported_method' }, { status: 400 })
}
