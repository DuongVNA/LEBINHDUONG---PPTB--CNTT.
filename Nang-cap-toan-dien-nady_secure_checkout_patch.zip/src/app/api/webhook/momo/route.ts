import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { canonicalize, hmacSHA256, constantTimeEqual } from '@/lib/security'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function POST(req: Request) {
  const raw = await req.text()
  let payload: any
  try { payload = JSON.parse(raw) } catch { return NextResponse.json({ error: 'invalid_json' }, { status: 400 }) }

  const secret = process.env.MOMO_SECRET_KEY!
  const dataToSign = canonicalize({
    amount: payload.amount,
    message: payload.message,
    orderId: payload.orderId,
    orderType: payload.orderType,
    partnerCode: payload.partnerCode,
    payType: payload.payType,
    requestId: payload.requestId,
    responseTime: payload.responseTime,
    resultCode: payload.resultCode,
    transId: payload.transId
  })
  const expected = hmacSHA256(dataToSign, secret)
  if (!constantTimeEqual(expected, String(payload.signature ?? ''))) {
    return NextResponse.json({ ok: false, reason: 'bad_signature' }, { status: 400 })
  }

  // Nonce window (±5m)
  const now = Date.now()
  const ts = Number(payload.responseTime ?? 0)
  if (!ts || Math.abs(now - ts) > 5*60*1000) {
    return NextResponse.json({ ok:false, reason:'stale_event' }, { status:400 })
  }

  const eventId = `momo:${payload.transId}`
  const existed = await prisma.paymentEvent.findUnique({ where: { eventId } })
  if (existed) return NextResponse.json({ ok: true, replay: true })

  await prisma.$transaction(async (tx) => {
    await tx.paymentEvent.create({ data: { provider: 'momo', eventId, rawPayload: payload, signature: payload.signature } })
    if (payload.resultCode === 0) {
      await tx.payment.update({ where: { orderId: payload.orderId }, data: { status: 'SUCCEEDED', providerRef: String(payload.transId) } })
      await tx.order.update({ where: { id: payload.orderId }, data: { status: 'PAID' } })
    } else {
      await tx.payment.update({ where: { orderId: payload.orderId }, data: { status: 'FAILED', providerRef: String(payload.transId) } })
      await tx.order.update({ where: { id: payload.orderId }, data: { status: 'FAILED' } })
    }
  })

  return NextResponse.json({ ok: true })
}
