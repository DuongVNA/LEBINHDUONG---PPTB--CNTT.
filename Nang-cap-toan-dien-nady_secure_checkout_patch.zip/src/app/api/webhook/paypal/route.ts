import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

async function verifyWithPayPal(headers: Headers, body: any) {
  const auth = 'Basic ' + Buffer.from(`${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`).toString('base64')
  const res = await fetch(`${process.env.PAYPAL_API}/v1/notifications/verify-webhook-signature`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: auth },
    body: JSON.stringify({
      transmission_id: headers.get('paypal-transmission-id'),
      transmission_time: headers.get('paypal-transmission-time'),
      cert_url: headers.get('paypal-cert-url'),
      auth_algo: headers.get('paypal-auth-algo'),
      transmission_sig: headers.get('paypal-transmission-sig'),
      webhook_id: process.env.PAYPAL_WEBHOOK_ID,
      webhook_event: body
    })
  })
  const json = await res.json()
  return json.verification_status === 'SUCCESS'
}

export async function POST(req: Request) {
  const raw = await req.text()
  let body: any
  try { body = JSON.parse(raw) } catch { return NextResponse.json({ error: 'invalid_json' }, { status: 400 }) }

  const ok = await verifyWithPayPal(req.headers, body).catch(() => false)
  if (!ok) return NextResponse.json({ error: 'bad_signature' }, { status: 400 })

  const id = `paypal:${body.id}`
  const existed = await prisma.paymentEvent.findUnique({ where: { eventId: id } })
  if (existed) return NextResponse.json({ ok: true, replay: true })

  await prisma.$transaction(async (tx) => {
    await tx.paymentEvent.create({ data: { provider: 'paypal', eventId: id, rawPayload: body } })
    const orderId = body.resource?.invoice_id || body.resource?.id
    if (body.event_type === 'PAYMENT.CAPTURE.COMPLETED') {
      await tx.payment.update({ where: { orderId }, data: { status: 'SUCCEEDED', providerRef: body.resource?.id } })
      await tx.order.update({ where: { id: orderId }, data: { status: 'PAID' } })
    } else if (String(body.event_type).startsWith('PAYMENT.')) {
      await tx.payment.update({ where: { orderId }, data: { status: 'FAILED', providerRef: body.resource?.id } })
      await tx.order.update({ where: { id: orderId }, data: { status: 'FAILED' } })
    }
  })

  return NextResponse.json({ ok: true })
}
