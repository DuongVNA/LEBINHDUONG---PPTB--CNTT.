import { createClient } from 'redis'
const r = createClient({ url: process.env.REDIS_URL as string })
r.connect().catch(()=>{})

/** Sliding window limiter using Redis sorted-set */
export async function slidingAllow(key: string, limit: number, windowSec: number) {
  const now = Date.now()
  const bucket = `rl:${key}`
  const tx = r.multi()
  tx.zRemRangeByScore(bucket, 0, now - windowSec*1000)
  tx.zAdd(bucket, [{ score: now, value: String(now) }])
  tx.zCard(bucket)
  tx.expire(bucket, windowSec)
  const [, , count] = await tx.exec() as any
  return (count ?? 0) <= limit
}
