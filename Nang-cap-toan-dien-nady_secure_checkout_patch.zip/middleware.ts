import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { slidingAllow } from './src/utils/rate'

const PROTECTED = [/^\/api\/checkout/i, /^\/api\/webhook\/.*/i]

export async function middleware(req: NextRequest) {
  const url = req.nextUrl.pathname
  if (PROTECTED.some(rx => rx.test(url))) {
    const ip = req.ip ?? req.headers.get('x-forwarded-for')?.split(',')[0] ?? '0.0.0.0'
    const scope = url.startsWith('/api/webhook') ? 'webhook' : 'checkout'
    const limit = scope === 'webhook' ? 300 : 50
    const ok = await slidingAllow(`${scope}:${ip}`, limit, 60)
    if (!ok) return NextResponse.json({ error: 'rate_limited' }, { status: 429 })
  }
  return NextResponse.next()
}

export const config = { matcher: ['/api/:path*'] }
